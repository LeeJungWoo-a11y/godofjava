package c.javapackage;

public class Package {
    public static void main(String[] args) {
        System.out.println("Package class.");
    }
}