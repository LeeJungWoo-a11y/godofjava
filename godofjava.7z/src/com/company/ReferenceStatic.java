public class ReferenceStatic {;
  public static void main(String args[]) {
    ReferenceStatic.staticMethod();
  }
  public static void staticMethod() {
    System.out.println("This is a staticMethod.");
  }
}
