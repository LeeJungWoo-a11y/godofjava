public class ReferenceConstructor {}
