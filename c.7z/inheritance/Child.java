package c.inheritance;

public class Child extends Parent{
    public Child() {
        System.out.println("Child Construcotr");
    }
}
