package c.inheritance;

public class ParentArg {
    public ParentArg(String name) {
        Sysem.out.println("ParentArg("+name+") Constructor");
    }
    public PaentArg(InheritancePrint obj) {
        System.out.println("ParentArg(InheritancePrint) Constructor");
    }

    public void printName() {
        System.out.println("printName() - ParentArg ");
    }
}

