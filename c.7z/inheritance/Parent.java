package c.inheritance;

public class Parent {
    public Parent() {
        // System.out.println("Parent Constructor");
    }
    public void printName() {
        System.out.println("Parent printName()");
    }
}
