package c.inheritance;

public class ParentOverriding {
}
