package c.inheritance;

public class ChildArg extends ParentArg {
    public ChildArg() {
        // super("ChildArg");
        syper(null);
        System.out.println("Child Constructor");
    }
}
