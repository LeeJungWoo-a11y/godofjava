package c.javapackage.sub;

public class Sub {
    public Sub() {

    }
    public void subClassMethod() {

    }
}
