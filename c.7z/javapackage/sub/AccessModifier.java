package c.javapackage.sub;

public class AccessModifier {
    public void publicMethod() {

    }
    protected void protectedMethod() {

    }
    void packagePrivateMethod() {

    }
    private void privateMethod() {

    }
}
