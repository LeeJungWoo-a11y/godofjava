package c.javapackage.sub;

public class Substatic {
    public final static String CLASS_NAME="SubSatic";
    public static void subStaticMethod() {
        System.out.println("subStaticMethod() is called.");
    }
}
