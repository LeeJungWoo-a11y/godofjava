package c.javapackage;

 public class PublicClass {
     public static void main(String args[]) {

     }

}
class PublicSecondClass{

}
